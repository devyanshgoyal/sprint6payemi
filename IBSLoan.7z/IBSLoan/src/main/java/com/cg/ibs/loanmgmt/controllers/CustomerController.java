package com.cg.ibs.loanmgmt.controllers;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.models.TransactionBean;
import com.cg.ibs.loanmgmt.models.Account;
import com.cg.ibs.loanmgmt.models.AccountHolding;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanDetailsDisplay;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanStatus;
import com.cg.ibs.loanmgmt.models.LoanTypeBean;
import com.cg.ibs.loanmgmt.services.ApplyLoanService;
import com.cg.ibs.loanmgmt.services.CustomerService;
import com.cg.ibs.loanmgmt.services.PayEmiService;

@Controller
@Scope("session")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private ApplyLoanService applyLoanService;
	@Autowired
	private PayEmiService payEmiService;
	private LoanTypeBean loanTypeBean = new LoanTypeBean();
	CustomerBean loggedInCustomer = new CustomerBean();
	private ModelAndView modelAndView = new ModelAndView();
	private LoanMaster globalLoanMaster = new LoanMaster();

	@RequestMapping("/applyLoan")
	public String applyLoan() {
		return "applyLoan";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/customer")
	public ModelAndView loginRole(@RequestParam("userId") String userId) {
		loggedInCustomer = customerService.getCustomer(userId);
		modelAndView.addObject("loginVerified", "Welcome " + customerService.getCustomer(userId).getFirstName());
		modelAndView.setViewName("loggedinCustomerPage");
		return modelAndView;
	}

	@RequestMapping(value = "/addLoan", method = RequestMethod.GET)
	public String showNewDeptPage() {
		return "addLoan";
	}

	@RequestMapping(value = "/homeCalculateEMI")
	public ModelAndView getDetailsForHomeLoan() {
		Integer typeId = 1;
		loanTypeBean = applyLoanService.getLoanTypeByTypeID(typeId);
		modelAndView.addObject("loanTypeBean", loanTypeBean);
		modelAndView.setViewName("homeCalculateEMI");
		globalLoanMaster.setTypeId(typeId);
		globalLoanMaster.setLoanInterest(loanTypeBean.getInterestRate());
		return modelAndView;
	}

	@RequestMapping(value = "/homeCalculateEMI2")
	public ModelAndView calculateEmi(@ModelAttribute LoanMaster loanMaster) {
		loanMaster.setLoanInterest(globalLoanMaster.getLoanInterest());
		globalLoanMaster.setEmiAmount(applyLoanService.calculateEmi(loanMaster).getEmiAmount());
		globalLoanMaster.setLoanAmount(loanMaster.getLoanAmount());
		globalLoanMaster.setBalance(loanMaster.getLoanAmount());
		globalLoanMaster.setLoanTenure(loanMaster.getLoanTenure());
		modelAndView.addObject("emi", globalLoanMaster.getEmiAmount());
		modelAndView.setViewName("homeCalculateEMI");
		return modelAndView;

	}

	@RequestMapping(value = "/homeCalculateEMI3")
	public ModelAndView displayTable() {
		List<LoanDetailsDisplay> tableList = new ArrayList<LoanDetailsDisplay>();
		LoanMaster loanMaster = globalLoanMaster;
		for (int i = 0; i < loanMaster.getLoanTenure(); i++) {
			BigDecimal interest = applyLoanService.calculatePaidInterest(loanMaster).setScale(4, RoundingMode.HALF_UP);
			BigDecimal principle = applyLoanService.calculatePaidPrinciple(loanMaster).setScale(4,
					RoundingMode.HALF_UP);
			loanMaster.setBalance(loanMaster.getBalance().subtract(principle).setScale(4, RoundingMode.HALF_UP));
			LoanDetailsDisplay display = new LoanDetailsDisplay(loanMaster.getEmiAmount(), principle, interest);
			tableList.add(display);
		}
		return new ModelAndView("homeCalculateEMI", "tableDisplay", tableList);
	}

	@RequestMapping(value = "/savingsAccountDetails")
	public ModelAndView getSavingsAccount() {
		List<AccountHolding> tableList = applyLoanService.getSavingAccountListByUci(loggedInCustomer);

		return new ModelAndView("savingsAccountDetailsPage", "tableList", tableList);
	}

//	@RequestMapping(value = "/submit")
//	public ModelAndView successUpload() {
//
//		return modelAndView;
//
//	}

	@RequestMapping(value = "/loanApplied")
	public ModelAndView loanSentForVerify(@ModelAttribute("btn") Account savAcc) {
		globalLoanMaster.setSavingsAccount(savAcc);
		;
		globalLoanMaster.setStatus(LoanStatus.SENT_FOR_VERIFICATION);
		globalLoanMaster.setBalance(globalLoanMaster.getLoanAmount());
		globalLoanMaster.setAppliedDate(LocalDate.now());
		globalLoanMaster.setUci(loggedInCustomer.getUci());
		applyLoanService.sendLoanForVerification(globalLoanMaster);
		return new ModelAndView("loanApplied", "appNum", globalLoanMaster.getApplicationNumber());

	}

	@RequestMapping(value = "/payEmi")
	public ModelAndView sendLoansWithEmi() {
		List<LoanMaster> loansWithDueEmi = payEmiService.getApprovedLoanListByUci(loggedInCustomer);
		return new ModelAndView("payEmi", "loansWithDueEmi", loansWithDueEmi);
	}

	@RequestMapping(value = "/payEmi1")
	public ModelAndView selectLoanForEmi(@RequestParam("loanNumber") BigInteger loanNumber) {
		List<LoanMaster> loansWithDueEmi = payEmiService.getApprovedLoanListByUci(loggedInCustomer);
		modelAndView.addObject("loansWithDueEmi", loansWithDueEmi);
		modelAndView.addObject("lNumber", loanNumber);
		globalLoanMaster.setLoanAccountNumber(loanNumber);
		modelAndView.setViewName("payEmi");
		return modelAndView;
	}

	@RequestMapping(value = "/payEmi2")
	public ModelAndView updateLoanPostEmi() {
		globalLoanMaster = payEmiService.getLoanByLoanNum(globalLoanMaster.getLoanAccountNumber());
		modelAndView.setViewName("payEmi");
		Duration diff = Duration.between(globalLoanMaster.getNextEmiDate().atStartOfDay(),
				LocalDate.now().atStartOfDay());
		long diffDays = diff.toDays();
		if (diffDays <= 3) {
			modelAndView.addObject("msg", "EMI paid.Thank You!");
			globalLoanMaster.setNumOfEmisPaid(globalLoanMaster.getNumOfEmisPaid() + 1);
			globalLoanMaster.setNextEmiDate(globalLoanMaster.getNextEmiDate().plusMonths(1));
			globalLoanMaster = payEmiService.updateLoanPostEmi(globalLoanMaster);
			modelAndView.addObject("updatedLoan", globalLoanMaster);
		} else {
			modelAndView.addObject("msg", "The EMI for this month has already been paid.");
		}

		return modelAndView;
	}

	@RequestMapping(value = "/payEmi3")
	public ModelAndView showTransaction() {
		TransactionBean transactionDebit = payEmiService.createDebitTransaction(globalLoanMaster);
		modelAndView.addObject("transDr", transactionDebit);
		TransactionBean transactionCredit = payEmiService.createCreditTransaction(globalLoanMaster);
		modelAndView.addObject("transCr", transactionCredit);
		modelAndView.setViewName("payEmi");
		return modelAndView;

	}
}