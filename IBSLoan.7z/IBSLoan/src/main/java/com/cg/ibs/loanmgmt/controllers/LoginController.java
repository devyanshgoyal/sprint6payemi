package com.cg.ibs.loanmgmt.controllers;

public class LoginController {

}
