package com.cg.ibs.loanmgmt.models;

public enum AccountType {
	SAVINGS, FIXED_DEPOSIT, RECURRING_DEPOSIT, JOINT_SAVINGS;
}
