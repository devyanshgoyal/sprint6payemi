package com.cg.ibs.loanmgmt.models;

public enum Gender {
	MALE, FEMALE, PREFER_NOT_TO_SAY;
}

